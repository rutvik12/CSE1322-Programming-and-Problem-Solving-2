class MyDate
{
    //Declaring private variables
    int year,month,day;
    
    public MyDate(int day,int month,int year)//Parameterized constructor
    {
       this.day=day;
       this.month=month;
       this.year=year;
    }
    public String toString()
    {
      String date=this.day+"/"+this.month+"/"+this.year;
      return date;
    }
}

